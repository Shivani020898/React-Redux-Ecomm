import React from 'react'

const Footer = () => {
  return (
    <div style={{backgroundColor:'blue',color:'white',padding:'10px'}}>
   <p>Designed and Developed By</p>
   <p>Shivani Tiwari</p>
    </div>
  )
}

export default Footer
